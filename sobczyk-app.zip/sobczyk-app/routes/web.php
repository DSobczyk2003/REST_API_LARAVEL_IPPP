<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\PeopleC;

Route::get('/', function () {
    return view('welcome');
});
Route::get('/damian/310794/people/index',[PeopleC::class,'index'])->name('people.index');
Route::get('/damian/310794/people/create',[PeopleC::class,'create'])->name('people.create');
Route::post('/damian/310794/people/create',[PeopleC::class,'add'])->name('people.add');
Route::get('/damian/310794/people/{people}/edit',[PeopleC::class,'edit'])->name('people.edit');
Route::put('/damian/310794/people/{people}/update', [PeopleC::class, 'update'])->name('people.update');
Route::delete('/damian/310794/people/{people}/delete', [PeopleC::class, 'delete'])->name('people.delete');
Route::get('/damian/310794/people/showById', [PeopleC::class, 'showById'])->name('people.showById');