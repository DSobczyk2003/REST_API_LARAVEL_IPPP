<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\People;

class PeopleC extends Controller

{

    public function index() 
    {
        $people =people::all();
        return view('damian.310794.people.index',['people'=>$people]);
        
    }

    public function create() 
    {
    return view('damian.310794.people.create');
    }

    public function add(Request $request) 
    {
       $data=$request->validate([
        'name'=>'required',
        'last_name'=>'required',
        'number_phone'=>'required|numeric',
        'street'=>'required',
        'country'=>'required',

       ]);
       $newPeople=People::create($data);
       return redirect(route('people.index'));
    }

    public function edit(people $people) 
{
    return view('damian.310794.people.edit', ['person' => $people]);
}

    public function update(People $people, Request $request) 
    {
        $data=$request->validate([
            'name'=>'required',
            'last_name'=>'required',
            'number_phone'=>'required|numeric',
            'street'=>'required',
            'country'=>'required',
    
           ]);
           $people->update($data);
           return redirect(route('people.index'));
    }
    public function delete(People $people) 
    {
        $people->delete();

        return redirect()->route('people.index')->with('success', 'Person deleted');
    }

    public function showById(Request $request)
    {
        $id = $request->input('id');
        $person = People::find($id);
    
        return view('damian.310794.people.show', ['person' => $person]);
    }
    
}