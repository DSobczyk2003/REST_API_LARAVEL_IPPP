<?
use Faker\Generator as Faker;
$factory->define(App\Models\People::class, function (Faker $faker) {
return [
'name' => $faker->name,
'last_name' => $faker->lastname,
 'phone_number' => $faker->phoneNumber,
  'street' => $faker->street_name,
   'country' => $faker->country
];
});

?>