<?php

namespace Database\Seeders; 

use Illuminate\Database\Seeder;
use App\Models\People;
use Faker\Factory as Faker;


class Random extends Seeder

{
    public function run()
    {
        $faker = Faker::create();
        
        foreach (range(0, 199) as $index) 
        {
            People::create
            ([
                'name' => $faker->firstName,
                'last_name' => $faker->lastName,
                'phone_number' => $faker->phoneNumber,
                'street' => $faker->streetAddress,
                'country' => $faker->country,
            ]);
        }
    }
}
